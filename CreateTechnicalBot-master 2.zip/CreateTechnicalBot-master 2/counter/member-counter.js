module.exports = async (client) =>{
const guild = client.guilds.cache.get('put CT discordguild id here');
setInterval(() =>{
const memberCount = guild.memberCount;
MessageChannel.channel.send("There are" + ${memberCount.toLocalString()} + "members in Create Technical")

},5000);

}