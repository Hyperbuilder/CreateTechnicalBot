# CreateTechnicalBot

a Discord.JS Bot with a SQlite3 Database for storing suggestions
RCON Connection to Minecraft servers. This has been Disabled for now
Status checker for Minecraft servers
