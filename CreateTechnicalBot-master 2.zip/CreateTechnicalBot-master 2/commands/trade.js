module.exports = {
    name: 'trade',
    description: "Start trading!",
    execute(message, commandArgs, command, MessageEmbed){
        return
    }
}