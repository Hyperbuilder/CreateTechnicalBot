module.exports =  [
    "What is your age?",
    "What is your Minecraft username?",
    "Why do you want to join Create Technical?",
    "Are you a technical player, a builder, or neither (does not matter which)?",
    "How did you find out about us?",
    "Tell us three facts about yourself!"
];